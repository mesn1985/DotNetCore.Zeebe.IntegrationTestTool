﻿namespace ZeebeBscProj.Models.WorkFlowModels
{
    public class DeployedWorkFlowModel
    {
        public int Version { get; set; }
        public string ProccesId { get; set; }
        public string WorkFlowKey { get; set; }
        public string RescourceName { get; set; }

    }
}
