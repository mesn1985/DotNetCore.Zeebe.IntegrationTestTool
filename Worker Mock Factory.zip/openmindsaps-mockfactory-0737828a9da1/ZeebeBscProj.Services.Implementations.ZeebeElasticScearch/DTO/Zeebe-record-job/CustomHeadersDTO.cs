﻿namespace ZeebeBscProj.Repositories.Implementations.ZeebeElasticScearch.DTO
{
    internal class CustomHeadersDTO
    {
    }
}
